# redes sociais

A Pen created on CodePen.io. Original URL: [https://codepen.io/leticiakruger/pen/QWXXdXZ](https://codepen.io/leticiakruger/pen/QWXXdXZ).

